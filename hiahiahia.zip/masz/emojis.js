module.exports = {
    fail: "<:wrong:822379358453891123> ",
    success: "<:check:822377045236514816> ",
  }